import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ConfirmPasswordValidator } from "../../confirm-password.validator";
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { UserDataService } from '../../services/user-data.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './registration.component.html',
  styleUrl: './registration.component.scss'
})
export class RegistrationComponent {
  errorMessage!: string;
  // defining myRegistrationForm as FormGroup
  myRegistrationForm!: FormGroup;
  // defining output information variable
  firstname_show!: string;
  lastname_show!: string;
  email_show!: string;
  username_show!: string;
  password_show!: string;
  confirmed_Password_show!: string;
  //output registration form is hidden by making flag false
  showRegistrationInfo: boolean = false;

  // Pattern for email
  email_pattern = "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}";

  constructor(private userDataService: UserDataService, private toustr: ToastrService,private router: Router,) {
    // FormGroup and FormControl are used for model driven form and validation performed 
    this.myRegistrationForm = new FormGroup({
      firstName: new FormControl('', Validators.required),
      lastName: new FormControl('', Validators.required),
      email: new FormControl('', [Validators.required, Validators.pattern(this.email_pattern)]),
      username: new FormControl('', [Validators.required, Validators.minLength(5), Validators.maxLength(12)]),
      password: new FormControl('', [Validators.required, Validators.minLength(8), Validators.maxLength(16)]),
      confirmPassword: new FormControl('', [Validators.required, Validators.minLength(8), Validators.maxLength(16)])
    });

  }

  // registration form submitted and data shown
  onRegisterFormSubmit() {


  

    // Accessing the form values
    this.firstname_show = this.myRegistrationForm.value.firstName;
    this.lastname_show = this.myRegistrationForm.value.lastName;
    this.email_show = this.myRegistrationForm.value.email;
    this.username_show = this.myRegistrationForm.value.username;
    this.password_show = this.myRegistrationForm.value.password;
    this.confirmed_Password_show = this.myRegistrationForm.value.confirmPassword;

    // Checking whether password and current password are same or not
    if (this.password_show != this.confirmed_Password_show) {
      this.errorMessage = "**Password and Confirm Password Not Matched";
    }
    else {
      // showing all entered value by making flag true
      this.showRegistrationInfo = true;

      // calling service to save data
      this.userDataService.checkUser(this.myRegistrationForm.value).subscribe((res) => {

        const json = JSON.stringify(res)
        const obj = JSON.parse(json)
        console.log(obj)
        if (obj[0] != undefined) {
          this.toustr.error("Username already exists", "Error")
        }
        else {
         
          this.userDataService.addUser(this.myRegistrationForm.value).subscribe(
            (response) => {
              this.toustr.success('Account created successfully');
            },
            error => {
              this.toustr.error("Error creating User", "Error")
            }
          );
          // Reset the form after submission
          this.myRegistrationForm.reset();
          this.router.navigate(['/login']);
        }
      });


      
      
      
      
      this.errorMessage = "";
    }
  }
}
