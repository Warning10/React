import { Component } from '@angular/core';
import { UserDataService } from '../../services/user-data.service';
import { FormsModule, NgForm, Validators, FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { json } from 'stream/consumers';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, CommonModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {
  //myLoginForm is defined as FormGroup
  myLoginForm!: FormGroup;
  users = []
  constructor(private user: UserDataService, private router: Router, private toastr: ToastrService) {
    // FormGroup and FormControl are used to validate the fields 
    this.myLoginForm = new FormGroup({
      username: new FormControl('', [
        Validators.required,
        Validators.minLength(5),
        Validators.maxLength(12),
        Validators.pattern("^[A-Za-z][A-Za-z0-9_]{4,13}")]),
      password: new FormControl('', [
        Validators.required,
        Validators.minLength(8), //For minimum character password
        Validators.maxLength(12)
      ])
    });
  }

  // login form on submitted
  public onLoginSubmit() {
    if (this.myLoginForm.valid) {
      const username = this.myLoginForm.value.username;
      const password = this.myLoginForm.value.password;

      this.user.checkUser(this.myLoginForm.value).subscribe((res) => {
        const json = JSON.stringify(res) // [] {}
        const obj = JSON.parse(json)
        console.log(obj[0]) //[{user}]
        if (obj[0] != null) {

          if (obj[0].username == username && obj[0].password == password) {
            // alert box to show entered data
            this.toastr.success("Login Successfully ", "Welcome " + username);
            // Set username in local storage
            localStorage.setItem('username', username)
            // Redirect to home page
            this.router.navigate(['/']);

          }
          else {
            this.toastr.error("Invalid username or password", "Error")
          }


        }
        else {
          this.toastr.error("Invalid username or password", "Error")
        }
      });


      // Login form reset
      this.myLoginForm.reset();
    }
    else {
      // Else alert box 
      alert("Please Enter username and password!!")
    }
  }
}
