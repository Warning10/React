import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router'; // Import RouterLink for navigation
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router'; // Import Router for navigation
import { UserDataService } from '../../services/user-data.service';

@Component({
  selector: 'app-nav-bar',
  standalone: true,
  imports: [RouterLink, CommonModule],
  templateUrl: './nav-bar.component.html',
  styleUrl: './nav-bar.component.scss'
})
export class NavBarComponent {

  constructor(private router: Router, public userService: UserDataService) { }

  isloggedin: boolean = false;
  username: any = '';

  ngOnInit() {
    // Check if user is logged in
    if (this.userService.isloggedin()) {
      // Redirect to login page

      this.username = this.getUsername();
      console.log(this.username)
    }
  }

  public getUsername() {
    return localStorage.getItem('username');
  }

  public logout() {
    // Remove username from local storage
    localStorage.removeItem('username');
    // Redirect to login page
    this.router.navigate(['/login']);
  }

}
