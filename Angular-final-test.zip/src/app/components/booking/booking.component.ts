import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ConfirmPasswordValidator } from "../../confirm-password.validator";
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { UserDataService } from '../../services/user-data.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { ActivatedRoute, ParamMap } from '@angular/router'

@Component({
  selector: 'app-booking',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './booking.component.html',
  styleUrl: './booking.component.scss'
})
export class BookingComponent {


  // defining car type array
  carType = ['Hatchback', 'Sedan', 'SUV', 'Luxury'];

  // defining car manufacturer array
  manufacturers = []

  errorMessage!: string;
  // defining myRegistrationForm as FormGroup
  myRegistrationForm!: FormGroup;

  id: any;



  constructor(private userDataService: UserDataService, private toustr: ToastrService, private router: Router, private route: ActivatedRoute) {



  }

  ngOnInit(): void {
    // getting id from the url
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.id = params.get('id') ?? null;

    })

    this.userDataService.getManufacturers().subscribe(
      (data: any) => {
        this.manufacturers = data;
      },
      (error) => {
        console.error('Error fetching manufacturers:', error);
      }
    );

    if (this.id != null) {
      // get booking data by id and set the form values
      this.userDataService.getBookingByID(this.id).subscribe((res) => {

        const json = JSON.stringify(res)
        const obj = JSON.parse(json)

        if (obj != undefined) {
          this.myRegistrationForm = new FormGroup({
            id: new FormControl(obj.id),
            firstName: new FormControl(obj.firstName, [Validators.required, Validators.pattern('^[a-zA-Z]+$')]),
            lastName: new FormControl(obj.lastName, [Validators.required, Validators.pattern('^[a-zA-Z]+$')]),
            mobileNum: new FormControl(obj.mobileNum, [Validators.required, Validators.pattern("[0-9]{10}")]),
            carType: new FormControl(obj.carType, Validators.required),
            manufacturer: new FormControl(obj.manufacturer, Validators.required),
            registrationNumber: new FormControl(obj.registrationNumber, [Validators.required, Validators.pattern('^[a-zA-Z]{2}\\d{2}[a-zA-Z]{2}\\d{4}$')]),
            vehiclePrice: new FormControl(obj.vehiclePrice, [Validators.required, Validators.min(0)]),
            purchaseDate: new FormControl(obj.purchaseDate, Validators.required)
          });
        }
      },
        error => this.toustr.error("Error fetching data", "Error")
      );
    }
    else {
      // FormGroup and FormControl are used for model driven form and validation performed 
      this.myRegistrationForm = new FormGroup({
        firstName: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z]+$')]),
        lastName: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z]+$')]),
        mobileNum: new FormControl('', [Validators.required, Validators.pattern("[0-9]{10}")]),
        carType: new FormControl('', Validators.required),
        manufacturer: new FormControl('', Validators.required),
        registrationNumber: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z]{2}\\d{2}[a-zA-Z]{2}\\d{4}$')]),
        vehiclePrice: new FormControl('', [Validators.required, Validators.min(0)]),
        purchaseDate: new FormControl('', Validators.required)
      });
    }
  }

  // registration form submitted and data shown
  onRegisterFormSubmit() {


    // Checking whether password and current password are same or not
    if (this.myRegistrationForm.invalid) {
      this.toustr.error("Something went wrong", "Error")
    }
    else {

      if (this.id != null) {
        this.userDataService.editBooking(this.myRegistrationForm.value).subscribe(
          (response) => {
            this.toustr.success('Booking updated successfully');
          },
          error => {
            this.toustr.error("Error updating booking", "Error")
          }
        );
        this.router.navigate(['/']);
      } else {
        // calling service to save data
        this.userDataService.checkBooking(this.myRegistrationForm.value).subscribe((res) => {

          const json = JSON.stringify(res)
          const obj = JSON.parse(json)
          console.log(obj)
          if (obj[0] != undefined) {
            this.toustr.error("Booking already exists", "Error")
          }
          else {
            console.log(this.myRegistrationForm.value);
            this.userDataService.addBooking(this.myRegistrationForm.value).subscribe(
              (response) => {
                this.toustr.success('Account created successfully');
              },
              error => {
                this.toustr.error("Error creating User", "Error")
              }
            );
            // Reset the form after submission
            this.myRegistrationForm.reset();
            this.router.navigate(['/']);
          }
        });
      }
      this.errorMessage = "";
    }
  }

}