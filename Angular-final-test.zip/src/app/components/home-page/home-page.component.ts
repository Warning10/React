import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { UserDataService } from '../../services/user-data.service';
import { CommonModule } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormControl, FormGroup, Validators, ReactiveFormsModule, FormsModule, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faRotateBack } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-home-page',
  standalone: true,
  imports: [RouterLink, CommonModule, ReactiveFormsModule, FormsModule, FontAwesomeModule],
  templateUrl: './home-page.component.html',
  styleUrl: './home-page.component.scss'
})
export class HomePageComponent {
  refreshIcon = faRotateBack;
  posts: any;


  currentPost: any = {
    id: 0,

  };

  constructor(private userDataService: UserDataService, private toastr: ToastrService, private titleService: Title, private router: Router) {
    this.loadData();
  }



  public loadData() {
    this.userDataService.getBooking().subscribe(posts => {
      console.log("Home Page 1")
      this.posts = posts;
    })
    console.log("Home Page 2")
  }

  public newBooking() {

    this.router.navigate(['/booking']);

  }

  public setCurrentPost(id: any) {
    this.currentPost = this.posts.find((post: any) => post.id === id)
  }

  public editBooking(id: any) {

    this.router.navigate(['/booking/' + id]);

  }

  public deleteBooking() {

    this.userDataService.deleteBooking(this.currentPost.id).subscribe((res) => {

      this.posts = this.posts.filter((post: any) => post.id !== this.currentPost.id)
      this.toastr.success("Booking Deleted Successfully")
    }, (err) => {
      this.toastr.error("Something Went Wrong")
    })

  }

}
