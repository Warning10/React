import { Routes } from '@angular/router';
import { HomePageComponent } from './components/home-page/home-page.component';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { authGuard } from './guard/auth.guard';
import { BookingComponent } from './components/booking/booking.component';
// Define the routes array
export const routes: Routes = [
    { path: '', component: HomePageComponent, canActivate: [authGuard] },
    { path: 'booking', component: BookingComponent, canActivate: [authGuard] },
    { path: 'booking/:id', component: BookingComponent, canActivate: [authGuard] },
    { path: 'login', component: LoginComponent },
    { path: 'register', component: RegistrationComponent }

];
