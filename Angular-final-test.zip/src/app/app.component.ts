// Import necessary modules and components
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NavBarComponent } from './components/nav-bar/nav-bar.component';
import { FooterComponent } from './components/footer/footer.component';
import { HttpClientModule } from  '@angular/common/http';
import { UserDataService } from './services/user-data.service';
import { provideHttpClient, withFetch } from '@angular/common/http';
import {  Title } from '@angular/platform-browser';


@Component({
  selector: 'app-root', // Component selector (used in HTML templates)
  standalone: true, // Indicates that this component is standalone (not part of a larger module)
  imports: [
    RouterOutlet, // Import the RouterOutlet for routing
    NavBarComponent, // Import the TopBarComponent
    FooterComponent, // Import the FooterComponent
    HttpClientModule, // Import the HttpClientModule for HTTP requests
    
  ],
  providers:[UserDataService,Title],
  templateUrl: './app.component.html', // Path to the HTML template file
  styleUrl: './app.component.scss', // Path to the SCSS (styles) file
})
export class AppComponent {
  title = 'AngularEnhance'; // A property to store the title of the app
}
