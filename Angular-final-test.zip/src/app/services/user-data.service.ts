import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { response } from 'express';

@Injectable({
  providedIn: 'root'
})
export class UserDataService {


  private josn_url_booking = 'http://localhost:3000/Booking'
  private josn_url_user = 'http://localhost:3000/User'
  private josn_url_manufacturer = 'http://localhost:3000/manufacturers'

  constructor(private http: HttpClient) { }


  ///

  addUser(user: any): Observable<any> {

    const json_data = JSON.stringify(user)

    return this.http.post(this.josn_url_user, json_data);

  }

  checkUser(user: any) {
    const url = 'http://localhost:3000/User?username=' + user.username
    return this.http.get(url)
  }

  getBooking() {

    return this.http.get(this.josn_url_booking);

  }

  getBookingByID(id: any) {

    return this.http.get(this.josn_url_booking + '/' + id);

  }

  checkBooking(booking: any) {
    const url = 'http://localhost:3000/Booking?registrationNumber=' + booking.registrationNumber
    return this.http.get(url)
  }

  addBooking(booking: any): Observable<any> {
    const json_data = JSON.stringify(booking)
    return this.http.post(this.josn_url_booking, json_data);
  }

  deleteBooking(id: any) {
    return this.http.delete(this.josn_url_booking + '/' + id)
  }

  editBooking(booking: any): Observable<any> {
    const json_data = JSON.stringify(booking)
    return this.http.put(this.josn_url_booking + '/' + booking.id, json_data)
  }

  getManufacturers() {
    return this.http.get(this.josn_url_manufacturer)
  }

  isloggedin() {
    if (typeof (localStorage) !== "undefined") {
      return localStorage.getItem('username') != null;
    }
    else {
      return false;

    }
  }

  logout() {
    if (typeof (localStorage) !== "undefined") {
      localStorage.removeItem('username');
    }

  }
}