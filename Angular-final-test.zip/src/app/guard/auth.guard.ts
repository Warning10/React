import { inject, Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { UserDataService } from "../services/user-data.service";

@Injectable({
  providedIn: 'root'
})
export class authGuard {
  constructor(private authService: UserDataService, private router: Router) { }

  canActivate(): boolean {
    if (this.authService.isloggedin()) {
      return true;
    } else {
      this.router.navigate(['/login']);
      return false;
    }
  }
}