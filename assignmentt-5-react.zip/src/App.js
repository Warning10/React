import "./App.css";
import ContactForm from "./Components/ContactForm";
import LoginForm from "./Components/LoginForm";
import Main from "./Components/Main";
import RegisterForm from "./Components/RegisterForm";
import Static from "./Components/Static";
import Footer from "./Layout/Footer";
import Navbar from "./Layout/Navbar";
import { BrowserRouter, Route, Routes } from "react-router-dom";



function App() {

  return (
    <div className="App">
      <BrowserRouter>
      <Navbar/>
      <Routes>
        <Route path="/" element={<Main />}>
          < Route path="/Static" element={<Static/>}/>
          </Route>
        <Route path="/login" element={<LoginForm />}/>
        <Route path="/register" element={<RegisterForm/>}/>
        <Route path="/contact" element={<ContactForm/>}/>
      </Routes>
      </BrowserRouter>
      <Footer/>
      </div>
  );
}

export default App;
