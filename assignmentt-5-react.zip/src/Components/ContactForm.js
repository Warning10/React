import React, { Component } from "react";
import "../Assets/css/ContactForm.css";

class ContactForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      email: "",
      message: "",
      errors: { name: "", email: "", message: "" },
      submittedName: "",
      submittedEmail: "",
      submittedMessage: "",
    };
  }

  handleChange = (event) => {
    const { name, value } = event.target;
    this.setState((prevState) => ({
      [name]: value,
      errors: {
        ...prevState.errors,
        [name]: "",
      },
    }));
  };

  handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = this.validate();
    this.setState({ errors: validationErrors });
    if (Object.values(validationErrors).every((error) => error === "")) {
      this.setState({
        submittedName: this.state.name,
        submittedEmail: this.state.email,
        submittedMessage: this.state.message,
      });
      // You can add further handling (e.g., sending data to backend) here
    }
  };

  handleReset = () => {
    this.setState({
      name: "",
      email: "",
      message: "",
      errors: { name: "", email: "", message: "" },
      submittedName: "",
      submittedEmail: "",
      submittedMessage: "",
    });
  };

  validate = () => {
    const { name, email, message } = this.state;
    let validationErrors = {};

    // Name validation
    if (!name) {
      validationErrors.name = "Name is required";
    }

    // Email validation
    if (!email) {
      validationErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      validationErrors.email = "Email is not valid";
    }

    // Message validation
    if (!message) {
      validationErrors.message = "Message is required";
    }

    return validationErrors;
  };

  render() {
    const { name, email, message, errors, submittedName, submittedEmail, submittedMessage } = this.state;

    return (
      <div className="container">
        <div className="form-container">
          <h2>Contact Us</h2>
          <form onSubmit={this.handleSubmit}>
            <div className="form-group">
              <label htmlFor="name">Name</label>
              <input
                type="text"
                name="name"
                value={name}
                onChange={this.handleChange}
                placeholder="Enter Your Name"
              />
              {errors.name && <div className="error">{errors.name}</div>}
            </div>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input
                type="text"
                name="email"
                value={email}
                onChange={this.handleChange}
                placeholder="Enter Your Email"
              />
              {errors.email && <div className="error">{errors.email}</div>}
            </div>
            <div className="form-group">
              <label htmlFor="message">Message</label>
              <textarea
                name="message"
                value={message}
                onChange={this.handleChange}
                placeholder="Enter Your Message"
              />
              {errors.message && <div className="error">{errors.message}</div>}
            </div>

            <div className="form-actions">
              <button className="submit-button" type="submit">Submit</button>
              <button className="reset-button" type="button" onClick={this.handleReset}>Reset</button>
            </div>

            {submittedName && submittedEmail && submittedMessage && (
              <div className="submitted-info">
                <h3>Submitted Information:</h3>
                <p><strong>Name:</strong> {submittedName}</p>
                <p><strong>Email:</strong> {submittedEmail}</p>
                <p><strong>Message:</strong> {submittedMessage}</p>
              </div>
            )}
          </form>
        </div>
      </div>
    );
  }
}

export default ContactForm;
