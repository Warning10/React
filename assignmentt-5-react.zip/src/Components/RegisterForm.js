import React, { Component } from "react";
import * as Yup from "yup";
import "../Assets/css/RegisterForm.css";

class RegisterForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      formData: {
        firstName: "",
        lastName: "",
        email: "",
        phoneNumber: "",
        password: "",
        confirmPassword: "",
        age: "",
        gender: "",
        interests: [],
        address: "", // New field: Address 
        country: "", // New field: Country
      },
      errors: {},
      submittedData: null,
    };

    this.validationSchema = Yup.object({
      firstName: Yup.string().required("First Name is Required"),
      lastName: Yup.string().required("Last Name is Required"),
      email: Yup.string()
        .required("Email is Required")
        .email("Invalid email format"),
      phoneNumber: Yup.string()
        .matches(/^\d{10}$/, "Phone Number must be 10 digits")
        .required("Phone Number is Required"),
      password: Yup.string()
        .required("Password is required")
        .min(8, "Password must be at least 8 characters")
        .matches(
          /[!@#$%^&*(),.?":{}|<>]/,
          "Password must contain at least one symbol"
        )
        .matches(/[0-9]/, "Password must contain at least one number")
        .matches(/[A-Z]/, "Password must contain at least one uppercase letter")
        .matches(
          /[a-z]/,
          "Password must contain at least one lowercase letter"
        ),
      confirmPassword: Yup.string()
        .oneOf([Yup.ref("password")], "Passwords must match")
        .required("Confirm password is required"),
      age: Yup.number()
        .typeError("Age must be a number")
        .min(18, "You must be at least 18 years old")
        .max(100, "You cannot be older than 100 years")
        .required("Age is required"),
      gender: Yup.string().required("Gender is required"),
      interests: Yup.array()
        .min(1, "Select at least one interest")
        .required("Select at least one interest"),
      address: Yup.string().required("Address is required"), // Validation for Address
      country: Yup.string().required("Country is required"), // Validation for Country
    });
  }

  handleSubmit = async (e) => {
    e.preventDefault();

    const { formData } = this.state;

    try {
      await this.validationSchema.validate(formData, { abortEarly: false });
      this.setState({
        submittedData: formData,
        errors: {},
      });
    } catch (error) {
      const newErrors = {};

      error.inner.forEach((err) => {
        newErrors[err.path] = err.message;
      });

      this.setState({
        errors: newErrors,
      });
    }
  };

  handleChange = (e) => {
    const { name, value } = e.target;
    const { formData, errors } = this.state;

    // Clear error for the current field
    const newErrors = { ...errors };
    delete newErrors[name];

    this.setState({
      formData: {
        ...formData,
        [name]: value,
      },
      errors: newErrors,
    });
  };

  handleCheckboxChange = (e) => {
    const { name, checked } = e.target;
    const { formData, errors } = this.state;
    let updatedInterests = [...formData.interests];

    if (checked) {
      updatedInterests.push(name);
    } else {
      updatedInterests = updatedInterests.filter(
        (interest) => interest !== name
      );
    }

    // Clear error for interests when at least one interest is selected
    const newErrors = { ...errors };
    if (updatedInterests.length > 0) {
      delete newErrors.interests;
    }

    this.setState({
      formData: {
        ...formData,
        interests: updatedInterests,
      },
      errors: newErrors,
    });
  };

  handleReset = () => {
    this.setState({
      formData: {
        firstName: "",
        lastName: "",
        email: "",
        phoneNumber: "",
        password: "",
        confirmPassword: "",
        age: "",
        gender: "",
        interests: [],
        address: "",
        country: "",
      },
      errors: {},
      submittedData: null,
    });
  };

  render() {
    const { formData, errors, submittedData } = this.state;

    return (
      <div>
        <form className="form" onSubmit={this.handleSubmit}>
          <div className="form-group">
            <h2 className="register-heading">Registration</h2>
            <label htmlFor="firstName">First Name:</label>
            <input
              type="text"
              id="firstName"
              name="firstName"
              value={formData.firstName}
              onChange={this.handleChange}
              className="form-control"
              placeholder="Enter your first name"
            />
            {errors.firstName && (
              <div className="error">{errors.firstName}</div>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="lastName">Last Name:</label>
            <input
              type="text"
              id="lastName"
              name="lastName"
              value={formData.lastName}
              onChange={this.handleChange}
              className="form-control"
              placeholder="Enter your last name"
            />
            {errors.lastName && <div className="error">{errors.lastName}</div>}
          </div>

          <div className="form-group">
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={this.handleChange}
              className="form-control"
              placeholder="Enter your email"
            />
            {errors.email && <div className="error">{errors.email}</div>}
          </div>

          <div className="form-group">
            <label htmlFor="phoneNumber">Phone Number:</label>
            <input
              type="text"
              id="phoneNumber"
              name="phoneNumber"
              value={formData.phoneNumber}
              onChange={this.handleChange}
              className="form-control"
              placeholder="Enter your phone number"
            />
            {errors.phoneNumber && (
              <div className="error">{errors.phoneNumber}</div>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="password">Password:</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={this.handleChange}
              className="form-control"
              placeholder="Enter your password"
            />
            {errors.password && <div className="error">{errors.password}</div>}
          </div>

          <div className="form-group">
            <label htmlFor="confirmPassword">Confirm Password:</label>
            <input
              type="password"
              id="confirmPassword"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={this.handleChange}
              className="form-control"
              placeholder="Confirm your password"
            />
            {errors.confirmPassword && (
              <div className="error">{errors.confirmPassword}</div>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="age">Age:</label>
            <input
              type="number"
              id="age"
              name="age"
              value={formData.age}
              onChange={this.handleChange}
              className="form-control"
              placeholder="Enter your age"
            />
            {errors.age && <div className="error">{errors.age}</div>}
          </div>

          <div className="form-group">
            <label>Gender:</label>
            <div>
              <label>
                <input
                  type="radio"
                  name="gender"
                  value="male"
                  checked={formData.gender === "male"}
                  onChange={this.handleChange}
                />{" "}
                Male
              </label>
              <label>
                <input
                  type="radio"
                  name="gender"
                  value="female"
                  checked={formData.gender === "female"}
                  onChange={this.handleChange}
                />{" "}
                Female
              </label>
            </div>
            {errors.gender && <div className="error">{errors.gender}</div>}
          </div>

          <div className="form-group">
            <label htmlFor="address">Address:</label>
            <textarea
              id="address"
              name="address"
              value={formData.address}
              onChange={this.handleChange}
              className="form-control"
              placeholder="Enter your address"
            />
            {errors.address && <div className="error">{errors.address}</div>}
          </div>

          <div className="form-group">
            <label htmlFor="country">Country:</label>
            <select
              id="country"
              name="country"
              value={formData.country}
              onChange={this.handleChange}
              className="form-control"
            >
              <option value="">Select Country</option>
              <option value="India">India</option>
              <option value="US">US</option>
              <option value="UK">UK</option>
            </select>
            {errors.country && <div className="error">{errors.country}</div>}
          </div>

          <div className="form-group">
            <label>Interests:</label>
            <div>
              <label>
                <input
                  type="checkbox"
                  name="coding"
                  checked={formData.interests.includes("coding")}
                  onChange={this.handleCheckboxChange}
                />{" "}
                Coding
              </label>
              <label>
                <input
                  type="checkbox"
                  name="sports"
                  checked={formData.interests.includes("sports")}
                  onChange={this.handleCheckboxChange}
                />{" "}
                Sports
              </label>
              <label>
                <input
                  type="checkbox"
                  name="reading"
                  checked={formData.interests.includes("reading")}
                  onChange={this.handleCheckboxChange}
                />{" "}
                Reading
              </label>
            </div>
            {errors.interests && (
              <div className="error">{errors.interests}</div>
            )}
          </div>
          <div>
            <button type="submit" className="btn-submit">
              Submit
            </button>

            <button
              type="button"
              className="btn-reset"
              onClick={this.handleReset}
            >
              Reset
            </button>
          </div>
          {submittedData && (
            <div className="submitted-data">
              <h2>Submitted Details</h2>
              <p>
                <strong>First Name:</strong> {submittedData.firstName}
              </p>
              <p>
                <strong>Last Name:</strong> {submittedData.lastName}
              </p>
              <p>
                <strong>Email:</strong> {submittedData.email}
              </p>
              <p>
                <strong>Phone Number:</strong> {submittedData.phoneNumber}
              </p>
              <p>
                <strong>Password:</strong> {submittedData.password}
              </p>
              <p>
                <strong>Age:</strong> {submittedData.age}
              </p>
              <p>
                <strong>Gender:</strong> {submittedData.gender}
              </p>
              <p>
                <strong>Address:</strong> {submittedData.address}
              </p>
              <p>
                <strong>Country:</strong> {submittedData.country}
              </p>
              <p>
                <strong>Interests:</strong> {submittedData.interests.join(", ")}
              </p>
            </div>
          )}
        </form>
      </div>
    );
  }
}

export default RegisterForm;
