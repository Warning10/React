import React from "react";
import "../Assets/css/Main.css";
import image from "../Assets/img/Banner.webp";
import Static from "./Static";
import { Link, Outlet } from "react-router-dom";

function Main() {
  return (
    <div className="App">
      <div className="banner">
        <div className="banner-content">
          <div className="text-container">
            <div className="content">
              <h3>
                <span className="header-message">Welcome to our</span>
              </h3>
              <h1>
                World's <br /> Creative Studio
              </h1>
              <button className="home-button" type="button"> <Link to={"/Static"}> Take a tour </Link></button>
            </div>
          </div>
          <img src={image} alt="Banner" className="banner-img" />
        </div>
      </div>
      <Outlet/>
    </div>
  );
}

export default Main;
