import React, { Component } from "react";
import "../Assets/css/LoginForm.css";

class LoginForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: "",
      password: "",
      errors: { email: "", password: "" },
      submittedEmail: "",
      submittedPassword: "",
    };
  }

  handleChange = (event) => {
    const { name, value } = event.target;

    // removing spaces
    if (value.trim() === " ") {
      return; // skip updating state if only spaces are entered
    }

    this.setState((prevState) => ({
      [name]: value.trim(), // trim spaces from input value
      errors: {
        ...prevState.errors,
        [name]: "",
      }, // clear errors when user starts typing again
    }));
  };

  handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = this.validate();
    this.setState({ errors: validationErrors });
    if (Object.values(validationErrors).every((error) => error === "")) {
      this.setState({
        submittedEmail: this.state.email,
        submittedPassword: this.state.password,
      });
    }
  };

  handleReset = () => {
    this.setState({
      email: "",
      password: "",
      errors: { email: "", password: "" },
      submittedEmail: "",
      submittedPassword: "",
    });
  };

  validate = () => {
    const { email, password } = this.state;
    let validationErrors = {};

    // Email validation
    if (!email) {
      validationErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      validationErrors.email = "Email is not valid";
    }

    // Password validation
    if (!password) {
      validationErrors.password = "Password is required";
    } else if (password.length < 8 || password.length > 15) {
      validationErrors.password =
        "Password must be between 8 and 15 characters long";
    } else if (!/\d/.test(password)) {
      validationErrors.password = "Password must contain at least one number";
    } else if (!/[a-zA-Z]/.test(password)) {
      validationErrors.password = "Password must contain at least one letter";
    } else if (!/[^a-zA-Z0-9\s]/.test(password)) {
      validationErrors.password =
        "Password must contain at least one special character and should not include spaces";
    } else if (/\s/.test(password)) {
      validationErrors.password = "Password should not contain spaces";
    }

    return validationErrors;
  };

  render() {
    const { email, password, errors, submittedEmail, submittedPassword } =
      this.state;

    return (
      <div className="container">
        <div id="form-container">
          <h2>Login</h2>
          <form onSubmit={this.handleSubmit}>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input
                type="text"
                name="email"
                value={email}
                onChange={this.handleChange}
                placeholder="Enter Email"
              />
              {errors.email && <div className="error">{errors.email}</div>}
            </div>
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input
                type="password"
                name="password"
                value={password}
                onChange={this.handleChange}
                placeholder="Enter Password"
              />
              {errors.password && (
                <div className="error">{errors.password}</div>
              )}
            </div>

            <div className="form-actions">
              <button className="submit-button" type="submit">Login</button>
              <button className="reset-button"type="button" onClick={this.handleReset}>
                Reset
              </button>
            </div>

            {submittedEmail && submittedPassword && (
              <div className="submitted-info">
                <h3>Submitted Information:</h3>
                <p>
                  <strong>Email:</strong> {submittedEmail}
                </p>
                <p>
                  <strong>Password:</strong> {submittedPassword}
                </p>
              </div>
            )}
          </form>
        </div>
      </div>
    );
  }
}

export default LoginForm;