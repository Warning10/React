import React, { Component } from "react";
import "../Assets/css/Navbar.css";
import logoSvg from "../Assets/img/logo.svg";
import { Link } from "react-router-dom";

class Navbar extends Component {
  state = { clicked: false };

  handleClick = () => {
    this.setState({ clicked: !this.state.clicked });
  };

  render() {
    return (
      <>
        <nav>
          <a>
            {" "}
            <Link to={"/"}>
              <img src={logoSvg} alt="Logo" />
            </Link>
          </a>
          <div>
            <h2>HarmonyHaven</h2>
          </div>

          <div></div>
        </nav>
        <div>
          <ul
            id="navbar"
            className={this.state.clicked ? "#navbar active" : "#navbar"}
          >
            <li>
              {" "}
              <a className="active">
                {" "}
                <Link to="/">Home</Link>
              </a>
            </li>
            <li>
              {" "}
              <a>
                {" "}
                <Link to="/login">Login </Link>
              </a>
            </li>

            <li>
              {" "}
              <a>
                {" "}
                <Link to="/register">Register </Link>
              </a>
            </li>
            <li>
              {" "}
              <a>
                {" "}
                <Link to="/contact">Contact </Link>
              </a>
            </li>
          </ul>
        </div>
        <div id="mobile" onClick={this.handleclik}>
          <i
            id="bar"
            className={this.state.clicked ? "fas fa-times" : "fas fa-bars"}
          ></i>
        </div>
      </>
    );
  }
}

export default Navbar;
