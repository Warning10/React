import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { Container, ListGroup, ListGroupItem, Button } from 'react-bootstrap';
import '../custom.css';


const AdminDashboard = () => {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const response = await axios.get('http://localhost:5000/users?role=student');
        setStudents(response.data);
      } catch (error) {
        console.error("Error fetching students:", error);
      }
    };
    fetchStudents();
  }, []);

  return (
    <Container className="admin-dashboard">
      <h2>Admin Dashboard</h2>
      <ListGroup>
        {students.map(student => (
          <ListGroupItem key={student.id}>
            {student.firstName} {student.lastName}
            <Button variant="link" as={Link} to={`/edit-access/${student.id}`}>
              Edit Access
            </Button>
          </ListGroupItem>
        ))}
      </ListGroup>
    </Container>
  );
};

export default AdminDashboard;
