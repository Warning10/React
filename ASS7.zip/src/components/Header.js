import React from 'react';
import { Link } from 'react-router-dom';
import { Navbar, Nav } from 'react-bootstrap';
import '../custom.css';


const Header = ({ user, onLogout }) => (
  <Navbar bg="dark" variant="dark" className="header">
    <Navbar.Brand className="logo">Company Logo</Navbar.Brand>
    <Nav className="mr-auto">
      <Navbar.Brand className="company-name">Company Name</Navbar.Brand>
    </Nav>
    {user && (
      <Nav>
        <Navbar.Text className="user-info">
          Welcome {user.firstName} {user.lastName}
        </Navbar.Text>
        <Nav.Link as={Link} to="/" onClick={onLogout}>Logout</Nav.Link>
      </Nav>
    )}
  </Navbar>
);

export default Header;
