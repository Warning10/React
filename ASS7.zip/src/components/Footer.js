import React from 'react';
import '../custom.css';


const Footer = () => (
  <footer className="footer">
    <p>© 2024 Company Name. All rights reserved.</p>
  </footer>
);

export default Footer;
