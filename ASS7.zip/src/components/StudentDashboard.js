import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Container, ListGroup, ListGroupItem } from 'react-bootstrap';
import '../custom.css';


const StudentDashboard = ({ user }) => {
  const [topics, setTopics] = useState([]);

  useEffect(() => {
    const fetchStudentTopics = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/users/${user.id}`);
        setTopics(response.data.topics);
      } catch (error) {
        console.error("Error fetching student topics:", error);
      }
    };
    fetchStudentTopics();
  }, [user.id]);

  return (
    <Container className="student-dashboard">
      <h2>Student Dashboard</h2>
      <ListGroup>
        {topics.length ? topics.map(topic => (
          <ListGroupItem key={topic}>
            <img src={`/${topic.toLowerCase()}.png`} alt={topic} /> {topic}
          </ListGroupItem>
        )) : <div>No subjects allotted. Please contact admin.</div>}
      </ListGroup>
    </Container>
  );
};

export default StudentDashboard;
