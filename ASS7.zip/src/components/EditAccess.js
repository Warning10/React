import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';
import { Container, Form, Button, FormGroup, FormCheck } from 'react-bootstrap';
import '../custom.css';


const EditAccess = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [topics, setTopics] = useState([]);
  const [selectedTopics, setSelectedTopics] = useState([]);

  useEffect(() => {
    const fetchSubjects = async () => {
      try {
        const response = await axios.get('http://localhost:5000/subjects');
        setTopics(response.data);
      } catch (error) {
        console.error("Error fetching subjects:", error);
      }
    };

    const fetchStudent = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/users/${id}`);
        setSelectedTopics(response.data.topics || []);
      } catch (error) {
        console.error("Error fetching student:", error);
      }
    };

    fetchSubjects();
    fetchStudent();
  }, [id]);

  const handleCheckboxChange = (topic) => {
    setSelectedTopics(prev =>
      prev.includes(topic) ? prev.filter(t => t !== topic) : [...prev, topic]
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.patch(`http://localhost:5000/users/${id}`, { topics: selectedTopics });
      toast.success("Access updated successfully");
      navigate('/admin');
    } catch (error) {
      toast.error("Error updating access");
    }
  };

  return (
    <Container className="edit-access">
      <h2>Edit Access</h2>
      <Form onSubmit={handleSubmit}>
        {topics.map(topic => (
          <FormGroup key={topic}>
            <FormCheck 
              type="checkbox"
              label={topic}
              checked={selectedTopics.includes(topic)}
              onChange={() => handleCheckboxChange(topic)}
            />
          </FormGroup>
        ))}
        <Button type="submit">Save</Button>
      </Form>
    </Container>
  );
};

export default EditAccess;
