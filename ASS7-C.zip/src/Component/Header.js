import React from "react";
import "../Custom.css";
import { useNavigate } from "react-router";

function Header() {
  const id = localStorage.getItem("id");
  const navigate = useNavigate();
  const handleLogout = () => {
    localStorage.clear();
    navigate("/");
  };

  return (
    <>
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <a className="navbar-brand" href="#">
          Assignment 2
        </a>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarResponsive"
          aria-controls="navbarResponsive"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div
          className="collapse navbar-collapse justify-content-end"
          id="navbarResponsive"
        >
          <ul className="navbar-nav ms-auto">
            <li className="nav-item active">
              <a
                className="nav-link"
                href="/"
                onClick={(e) => handleLogout(e)}
              >
                Logout
              </a>
            </li>
            {id == "4" && (
              <li className="nav-item active">
                <a className="nav-link" href="/adminDashboard">
                  Dashboard
                </a>
              </li>
            )}
          </ul>
        </div>
      </nav>
    </>
  );
}

export default Header;
