import React from "react";

function Footer() {
  return (
    <>
      <footer
        id="sticky-footer"
        className="flex-shrink-0 py-4 bg-dark fixed-bottom"
        style={{ color: "white" }}
      >
        <div className="text-center">
          <small>Copyright &copy; Your Website</small>
        </div>
      </footer>
    </>
  );
}

export default Footer;
