import React, { useEffect, useState } from "react";
import "../Custom.css";
import axios from "axios";
import "@fortawesome/fontawesome-free/css/all.min.css";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useNavigate } from "react-router-dom";

function LoginPage() {
  const navigate = useNavigate();
  const [data, setData] = useState({
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    setData((preData) => ({
      ...preData,
      [e.target.name]: e.target.value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!data.email || !data.password) {
      toast("Email and Password is required");
      return;
    } else if (!emailRegex.test(data.email)) {
      toast("Please enter correct email");
      return;
    }

    const response = await axios.get("http://localhost:3000/users", {
      params: { email: data.email, password: data.password },
    });

    localStorage.setItem("id", response.data[0].id);
    localStorage.setItem("status", response.data[0].status);
    if (response.data[0].status == 1) {
      navigate("/userDashboard");
    } else {
      navigate("/adminDashboard");
    }
  };

  return (
    <>
      <div className="container-login h-100">
        <ToastContainer />
        <div className="d-flex justify-content-center">
          <div className="card">
            <div className="card-header">
              <h3>Sign In</h3>
            </div>
            <div className="card-body">
              <form>
                <div className="input-group form-group">
                  <div className="input-group-prepend">
                    <span className="input-group-text">
                      <i className="fas fa-user"></i>
                    </span>
                  </div>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="email"
                    name="email"
                    onChange={(e) => handleChange(e)}
                    value={data.email}
                  />
                </div>
                <div className="input-group form-group">
                  <div className="input-group-prepend">
                    <span className="input-group-text">
                      <i className="fas fa-key"></i>
                    </span>
                  </div>
                  <input
                    type="password"
                    className="form-control"
                    name="password"
                    placeholder="password"
                    onChange={(e) => handleChange(e)}
                    value={data.password}
                  />
                </div>
                <div className="form-group">
                  <input
                    type="submit"
                    value="Login"
                    className="btn float-center login_btn"
                    onClick={(e) => handleSubmit(e)}
                  />
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default LoginPage;
