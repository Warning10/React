import React, { useEffect, useState } from "react";
import Header from "./Header";
import Footer from "./Footer";
import data from "../data.json";
import { useParams } from "react-router-dom";
import axios from "axios";
import "../Custom.css";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function EditAccess() {
  const { id } = useParams();
  const [permanentAccess, setPermanentAccess] = useState(false);
  const [globalExpirationDate, setGlobalExpirationDate] = useState("");
  const [topicArray, setTopicArray] = useState([]);

  const fetchData = async () => {
    const response = await axios.get(`http://localhost:3000/users/${id}`);
    setTopicArray(response.data.topicsArray);
    setPermanentAccess(response.data.permanentAccess);
    setGlobalExpirationDate(response.data.globalExpirationDate);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handlePermanentAccess = (e) => {
    setPermanentAccess(e.target.checked);
    if (e.target.checked) {
      setGlobalExpirationDate("");
    }
  };

  const handleGlobalExpirationDateChange = (e) => {
    setGlobalExpirationDate(e.target.value);
  };

  const handleTopics = (id) => {
    const updatedArray = topicArray.includes(id)
      ? topicArray.filter((topicId) => topicId != id)
      : [...topicArray, id];
    setTopicArray(updatedArray);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const response = await axios.patch(`http://localhost:3000/users/${id}`, {
      topicsArray: topicArray,
      permanentAccess: permanentAccess,
      globalExpirationDate: globalExpirationDate,
    });
    toast("Successfully Updated");
  };

  return (
    <>
      <Header />
      <form className="editForm">
        <div className="container-edit" style={{ marginTop: "8%" }}>
          <ToastContainer />
          <div className="form-group form-check d-flex">
            <input
              type="checkbox"
              className="form-check-input"
              id="permanentAccessCheckbox"
              checked={permanentAccess}
              onChange={(e) => handlePermanentAccess(e)}
            />
            <label
              className="form-check-label"
              htmlFor="permanentAccessCheckbox"
            >
              Permanent access
            </label>
          </div>
          <div className="form-group">
            <label htmlFor="globalExpirationDate" className="d-flex">
              Global expiration date:
            </label>
            <input
              type="date"
              id="globalExpirationDate"
              className="form-control"
              disabled={permanentAccess}
              value={globalExpirationDate}
              onChange={(e) => handleGlobalExpirationDateChange(e)}
              style={{ width: "41%" }}
            />
          </div>
          <div className="form-group form-check">
            {data.topics.map((top) => (
              <div className="d-flex" key={top.id}>
                <input
                  type="checkbox"
                  id={`Topic${top.id}`}
                  className="form-check-input"
                  value={top.id}
                  onChange={(e) => handleTopics(e.target.value)}
                  checked={topicArray.includes(top.id)}
                />
                <label className="form-check-label" htmlFor={`Topic${top.id}`}>
                  {top.topic}
                </label>
              </div>
            ))}
          </div>
          <button
            type="submit"
            onClick={(e) => handleSubmit(e)}
            className="submit-edit d-flex"
          >
            Submit
          </button>
        </div>
      </form>
      <Footer />
    </>
  );
}

export default EditAccess;
