import React, { useEffect, useState } from "react";
import axios from "axios";
import "../Custom.css";
import Header from "./Header";
import Footer from "./Footer";
import "@fortawesome/fontawesome-free/css/all.min.css";

function UserDashboard() {
  const id = localStorage.getItem("id");
  const [topicData, setTopicData] = useState(() => {
    const storedData = localStorage.getItem("topicData");
    return storedData ? JSON.parse(storedData) : [];
  });

  const fetchData = async () => {
    const response = await axios.get(`http://localhost:3000/users/${id}`);
    const topicArray = response.data.topicsArray;

    const topicDataresponse = await Promise.all(
      topicArray.map(async (top) => {
        const response = await axios.get(`http://localhost:3000/topics/${top}`);
        return response.data;
      })
    );
    setTopicData(topicDataresponse);
    localStorage.setItem("topicData", JSON.stringify(topicDataresponse));
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <>
      <Header />
      <section id="fh5co-intro">
        <div className="container">
          <div className="row row-bottom-padded-lg">
            {topicData.length <= 0 ? (
              <div style={{ marginTop: "8%" }}>There is no data available</div>
            ) : (
              topicData.map((top) => (
                <div
                  className="fh5co-block to-animate"
                  style={{ backgroundImage: "url(images/img_7.jpg)" }}
                  key={top.id}
                >
                  <div className="overlay-darker"></div>
                  <div className="overlay"></div>
                  <div className="fh5co-text">
                    {top.topic === "History" ? (
                      <i className="fas fa-history"></i>
                    ) : (
                      ""
                    )}
                    {top.topic === "Geography" ? (
                      <i className="fas fa-globe"></i>
                    ) : (
                      ""
                    )}
                    {top.topic === "Maths" ? (
                      <i className="fas fa-calculator"></i>
                    ) : (
                      ""
                    )}
                    {top.topic === "Science" ? (
                      <i className="fas fa-flask"></i>
                    ) : (
                      ""
                    )}
                    {top.topic === "Economics" ? (
                      <i className="fas fa-chart-line"></i>
                    ) : (
                      ""
                    )}
                    <h2>{top.topic}</h2>
                    <p>
                      There's a sign on the wall, But she wants to be sure
                      'Cause you know sometimes words have two meanings.
                    </p>
                    <p>
                      <a href="#" className="btn btn-primary">
                        Get In Touch
                      </a>
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}

export default UserDashboard;
