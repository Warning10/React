import React, { useState } from "react";
import Header from "./Header";
import Footer from "./Footer";
import data from "../data.json";

function AdminDashboard() {
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const recordsPerPage = 4;

  const filteredStudents = data.users.filter((stud) => {
    const firstName = stud.firstName.toLowerCase();
    const lastName = stud.lastName.toLowerCase();
    const email = stud.email.toLowerCase();
    return (
      firstName.includes(searchQuery) ||
      lastName.includes(searchQuery) ||
      email.includes(searchQuery)
    );
  });

  const totalPages = Math.ceil(filteredStudents.length / recordsPerPage);

  const handlePrevPage = () => {
    setCurrentPage((prevPage) => Math.max(prevPage - 1, 1));
  };

  const handleNextPage = () => {
    setCurrentPage((prevPage) => Math.min(prevPage + 1, totalPages));
  };

  const goToPage = (pageNumber) => {
    setCurrentPage(Math.min(Math.max(pageNumber, 1), totalPages));
  };

  const startIndex = (currentPage - 1) * recordsPerPage;
  const endIndex = startIndex + recordsPerPage;
  const currentStudents = filteredStudents.slice(startIndex, endIndex);

  return (
    <>
      <Header />
      <div
        className="container"
        style={{
          marginTop: "10%",
          padding: "20px 25px 29px 25px",
          border: "2px solid #d8d8d8",
        }}
      >
        <div
          className="mb-2"
          style={{ width: "30%", float: "left", marginBottom: "40px" }}
        >
          <input
            type="text"
            className="form-control"
            placeholder="Search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <table className="table table-striped">
          <thead>
            <tr>
              <th scope="col">First Name</th>
              <th scope="col">Last Name</th>
              <th scope="col">Student ID</th>
              <th scope="col">Email</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {currentStudents.map((stud) => (
              <tr key={stud.id}>
                <td>{stud.firstName}</td>
                <td>{stud.lastName}</td>
                <td>{stud.id}</td>
                <td>{stud.email}</td>
                <td>
                  <a href={`/editAccess/${stud.id}`}>Edit</a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <nav style={{ marginBottom: "6%" }}>
          <ul className="pagination justify-content-center">
            <li className={`page-item ${currentPage === 1 ? "disabled" : ""}`}>
              <button className="page-link" onClick={handlePrevPage}>
                Previous
              </button>
            </li>
            {[...Array(totalPages).keys()].map((page) => (
              <li
                key={page}
                className={`page-item ${
                  page + 1 === currentPage ? "active" : ""
                }`}
              >
                <button
                  className="page-link"
                  onClick={() => goToPage(page + 1)}
                >
                  {page + 1}
                </button>
              </li>
            ))}
            <li
              className={`page-item ${
                currentPage === totalPages ? "disabled" : ""
              }`}
            >
              <button className="page-link" onClick={handleNextPage}>
                Next
              </button>
            </li>
          </ul>
        </nav>
      </div>
      <Footer />
    </>
  );
}

export default AdminDashboard;
