import { Route, Router, Routes } from 'react-router-dom';
import './App.css';
import LoginPage from './Component/LoginPage';
import UserDashboard from './Component/UserDashboard';
import AdminDashboard from './Component/AdminDashboard';
import EditAccess from './Component/EditAccess';

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="" element={<LoginPage/>}/>
        <Route path="/userDashboard" element={<UserDashboard/>}/>
        <Route path="/adminDashboard" element={<AdminDashboard/>}/>
        <Route path="/editAccess/:id" element={<EditAccess/>}/>
      </Routes>
    </div>
  );
}

export default App;
