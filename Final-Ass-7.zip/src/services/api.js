import axios from 'axios';

const API = axios.create({
  baseURL: 'http://localhost:5000'
});

export const fetchUserByEmailAndPassword = (email, password) =>
  API.get(`/users?email=${email}&password=${password}`);

export const fetchStudents = () =>
  API.get('/users?role=student');

export const fetchSubjects = () =>
  API.get('/subjects');

export const fetchStudentById = (id) =>
  API.get(`/users/${id}`);

export const updateStudentTopics = (id, topics) =>
  API.patch(`/users/${id}`, { topics });
