import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './components/Login';
import AdminDashboard from './components/AdminDashboard';
import StudentDashboard from './components/StudentDashboard';
import EditAccess from './components/EditAccess';
import Header from './components/Header';
import Footer from './components/Footer';
import { ToastContainer } from 'react-toastify';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'
import 'react-toastify/dist/ReactToastify.css';
import { toast } from 'react-toastify';


function App() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const handleLogin = (user) => {
    setUser(user);
  };

  const handleLogout = () => {
    localStorage.removeItem('user');
    setUser(null);
    toast.success("Logged-out");
  };

  return (
    <Router>
      <div className="App vh-100" >
        <Header user={user} onLogout={handleLogout} />
        <div className='d-flex justify-content-center align-items-center h-90 main-back'>
        <Routes>
          <Route path="/" element={<Login onLogin={handleLogin} />} />
          <Route path="/admin" element={user && user.role === 'admin' ? <AdminDashboard /> : <Login onLogin={handleLogin} />} />
          <Route path="/student" element={user && user.role === 'student' ? <StudentDashboard user={user} /> : <Login onLogin={handleLogin} />} />
          <Route path="/edit-access/:id" element={user && user.role === 'admin' ? <EditAccess /> : <Login onLogin={handleLogin} />} />
        </Routes>
        <ToastContainer />
        </div>
        <Footer />
        
      </div>
    </Router>
  );
}

export default App;
