import React from 'react';
import { Link } from 'react-router-dom';
import { Navbar, Nav, NavDropdown } from 'react-bootstrap';
import '../assets/css/Header.css';
import logo from '../assets/img/logoipsum.svg'
const Header = ({ user, onLogout }) => (
  <Navbar bg="dark" variant="dark" className="d-flex justify-content-between flex-row">
    <Nav.Item className="logo ps-2 ">
    <img src={logo} alt="My logo" />
    
    </Nav.Item>
    <Nav.Item className="fs-4 text-center text-white">Aress Software</Nav.Item>
    {user && (
      <Nav className="ml-auto pe-4">
        <NavDropdown title={`Welcome ${user.firstName} ${user.lastName}`} id="basic-nav-dropdown">
          <NavDropdown.Item as={Link} to="/" onClick={onLogout}>Logout</NavDropdown.Item>
        </NavDropdown>
      </Nav>
    )}
    {!user &&
    (
      <Nav.Item as={Link} to="/" className='fs-5 text-white pe-3'>Login</Nav.Item>
    )
    }
  </Navbar>
);

export default Header;