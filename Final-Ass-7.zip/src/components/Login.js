import React from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';
import { Container, Button, FormGroup, FormLabel, FormControl } from 'react-bootstrap';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import "../assets/css/LoginForm.css"
// Define the validation schema using Yup
const LoginSchema = Yup.object().shape({
  email: Yup.string().email('Invalid email').required('Email is required'),
  password: Yup.string().required('Password is required'),
});

const Login = ({ onLogin }) => {
  const navigate = useNavigate();

  const handleSubmit = async (values, { setSubmitting }) => {
    try {
      const response = await axios.get(`http://localhost:5000/users?email=${values.email}&password=${values.password}`);
      const user = response.data[0];
      if (user) {
        localStorage.setItem('user', JSON.stringify(user));
        onLogin(user);
        navigate(user.role === 'admin' ? '/admin' : '/student');
      } else {
        toast.error("Invalid email or password");
      }
    } catch (error) {
      toast.error("An error occurred. Please try again.");
    }
    setSubmitting(false);
  };

  return (
    <div className=' w-100 h-100 d-flex justify-content-center align-items-center login-background'>
    <Container className="login-container shadow p-3">
      <h2>
        Login</h2>
      <Formik
        initialValues={{ email: '', password: '' }}
        validationSchema={LoginSchema}
        onSubmit={handleSubmit}
      >
        {({ isSubmitting }) => (
          <Form className='m-2 p-2'>
            <FormGroup>
              <FormLabel>Email</FormLabel>
              <Field
                type="email"
                name="email"
                as={FormControl}
              />
              <ErrorMessage name="email" component="div" className="error-message" />
            </FormGroup>
            <FormGroup>
              <FormLabel>Password</FormLabel>
              <Field
                type="password"
                name="password"
                as={FormControl}
              />
              <ErrorMessage name="password" component="div" className="error-message" />
            </FormGroup>
            <Button className='my-2' type="submit" disabled={isSubmitting}>Login</Button>
          </Form>
        )}
      </Formik>
    </Container>
    </div>
  );
};

export default Login;
