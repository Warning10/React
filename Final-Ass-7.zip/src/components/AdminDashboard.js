import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Container, Table } from 'react-bootstrap';
import '../custom.css';

const AdminDashboard = () => {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const response = await axios.get('http://localhost:5000/users?role=student');
        setStudents(response.data);
      } catch (error) {
        console.error("Error fetching students:", error);
      }
    };
    fetchStudents();
  }, []);

  const handleEdit = (id) => {
    // Navigate programmatically to the edit page for the student with given id
    window.location.href = `/edit-access/${id}`;
  };

  return (
    <Container className=" bg-white rounded shadow p-3">
      <h2>Admin Dashboard</h2>
      <div className=' h-100'>
      <Table className='  rounded'  bordered hover>
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Subjects Allotted</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {students.map((student) => (
            <tr key={student.id}>
              <td>{student.id}</td>
              <td>{student.firstName} {student.lastName}</td>
              <td>{student.email}</td>
              <td>
                {student.topics && student.topics.length > 0 ? (
                  <ul className='d-flex flex-row'>
                     {student.topics.map((subject, index) => (
                      <li key={index}>| {subject} |</li>
                    ))} 
                  </ul>
                ) : (
                  <div>No subjects allotted</div>
                )}
              </td>
              <td>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={() => handleEdit(student.id)}
                >
                  Edit
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
      </div>
    </Container>
  );
};

export default AdminDashboard;
