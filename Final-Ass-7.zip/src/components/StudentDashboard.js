import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Container, ListGroup } from 'react-bootstrap';
import '../custom.css';

const StudentDashboard = ({ user }) => {
  const [topics, setTopics] = useState([]);

  useEffect(() => {
    const fetchStudentTopics = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/users/${user.id}`);
        setTopics(response.data.topics);
      } catch (error) {
        console.error("Error fetching student topics:", error);
      }
    };
    fetchStudentTopics();
  }, [user.id]);

  const renderTopicIcon = (topic) => {
    switch (topic) {
      case "History":
        return <i className="fas fa-history"></i>;
      case "Geography":
        return <i className="fas fa-globe"></i>;
      case "Maths":
        return <i className="fas fa-calculator"></i>;
      case "Science":
        return <i className="fas fa-flask"></i>;
      case "Economics":
        return <i className="fas fa-chart-line"></i>;
      default:
        return null;
    }
  };

  return (
    <Container className="student-dashboard bg-white rounded shadow">
      <h2>Student Dashboard</h2>
      <ListGroup>
        {topics.length ? (
          topics.map((topic, index) => (
            <ListGroup.Item key={index} className="d-flex align-items-center fs-5">
              {renderTopicIcon(topic)}
              <span style={{ marginLeft: '10px' }}>{topic}</span>
            </ListGroup.Item>
          ))
        ) : (
          <ListGroup.Item>
           <h5>No subjects allotted. Please contact admin.</h5> 
          </ListGroup.Item>
        )}
      </ListGroup>
    </Container>
  );
};

export default StudentDashboard;
