import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';
import { Container, Form, Button, FormGroup, FormCheck } from 'react-bootstrap';
import '../custom.css';

const EditAccess = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [topics, setTopics] = useState([]);
  const [selectedTopics, setSelectedTopics] = useState([]);

  useEffect(() => {
    const fetchUserAndSubjects = async () => {
      try {
        // Fetch user details
        const userResponse = await axios.get(`http://localhost:5000/users/${id}`);
        setUser(userResponse.data);

        // Fetch available subjects/topics
        const subjectsResponse = await axios.get('http://localhost:5000/subjects');
        setTopics(subjectsResponse.data);

        // Set selected topics from user data
        setSelectedTopics(userResponse.data.topics || []);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchUserAndSubjects();
  }, [id]);

  const handleCheckboxChange = (topic) => {
    setSelectedTopics((prevSelectedTopics) =>
      prevSelectedTopics.includes(topic)
        ? prevSelectedTopics.filter((t) => t !== topic)
        : [...prevSelectedTopics, topic]
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Update user with selected topics
      await axios.patch(`http://localhost:5000/users/${id}`, { topics: selectedTopics });
      toast.success("Access updated successfully");
      navigate('/admin');
    } catch (error) {
      toast.error("Error updating access");
    }
  };

  const handleCancel = () => {
    navigate('/admin');
  };

  if (!user) {
    return <Container>Loading...</Container>; // Placeholder for when user data is being fetched
  }

  return (
    <Container className="edit-access shadow bg-white  mt-5 rounded p-5">
      <h2 className='fs-2'>Edit Access for {user.firstName} {user.lastName}</h2>
      <p className='fs-5'>Email: {user.email}</p>
      <Form onSubmit={handleSubmit}>
        {topics.map((topic) => (
          <FormGroup key={topic}>
            <FormCheck
              className='fs-4'
              type="checkbox"
              label={topic}
              checked={selectedTopics.includes(topic)}
              onChange={() => handleCheckboxChange(topic)}
            />
          </FormGroup>
        ))}
        <div className='pt-3'>
          <Button type="submit" className="mr-2">Save</Button>
          <Button variant="secondary" onClick={handleCancel}>Cancel</Button>
        </div>
      </Form>
    </Container>
  );
};

export default EditAccess;
