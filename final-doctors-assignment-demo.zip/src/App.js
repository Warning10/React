import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Login from './components/Login';
import Appointments from './components/Appointments';
import AppointmentForm from './components/AppointmentForm';
import './custom.module.css';

const App = () => {
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('user')));

  const handleLogin = (user) => {
    setUser(user);
    localStorage.setItem('user', JSON.stringify(user));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  return (
    <Router>
      <div className="app">
        <Header user={user} onLogout={handleLogout} />
        <div className="container">
          <Routes>
            <Route
              path="/login"
              element={user ? <Navigate to="/appointments" /> : <Login onLogin={handleLogin} />}
            />
            <Route
              path="/appointments"
              element={user ? <Appointments /> : <Navigate to="/login" />}
            />
            <Route
              path="/appointment/new"
              element={user ? <AppointmentForm /> : <Navigate to="/login" />}
            />
            <Route
              path="/appointment/:id/edit"
              element={user ? <AppointmentForm /> : <Navigate to="/login" />}
            />
            <Route
              path="/"
              element={<Navigate to="/login" />}
            />
          </Routes>
        </div>
        <Footer />
      </div>
    </Router>
  );
};

export default App;
