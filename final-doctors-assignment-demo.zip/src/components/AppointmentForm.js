import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Formik, Form, Field, useFormikContext } from 'formik';
import * as Yup from 'yup';
import toastr from 'toastr';
import { getDiseases, addAppointment, updateAppointment, getAppointmentById } from '../services/api';

const AppointmentForm = () => {
  const [diseases, setDiseases] = useState([]);
  const { id } = useParams();
  const history = useNavigate();
  const isEdit = !!id;
  const formik = useFormikContext(); // Get formik context

  useEffect(() => {
    const fetchDiseases = async () => {
      try {
        const data = await getDiseases();
        setDiseases(data);
      } catch (error) {
        console.error('Failed to fetch diseases:', error);
        toastr.error('Failed to fetch diseases');
      }
    };

    const fetchAppointment = async () => {
      try {
        if (isEdit) {
          const data = await getAppointmentById(id);
          formik.setValues(data); // Set form values using formik context
        }
      } catch (error) {
        console.error('Failed to fetch appointment:', error);
        toastr.error('Failed to fetch appointment details');
      }
    };

    fetchDiseases();
    fetchAppointment();
  }, [id, isEdit, formik]); // Ensure formik is included in dependencies

  const validationSchema = Yup.object({
    firstName: Yup.string().required('Required'),
    lastName: Yup.string().required('Required'),
    mobileNumber: Yup.string().matches(/^[0-9]{10}$/, 'Must be a valid 10 digit mobile number').required('Required'),
    birthDate: Yup.date().max(new Date(), 'Birth date must be in the past').required('Required'),
    gender: Yup.string().required('Required'),
    disease: Yup.string().required('Required'),
    history: Yup.string().required('Required'),
    appointmentDateTime: Yup.date().min(new Date(), 'Appointment date and time must be in the future').required('Required'),
  });

  const handleSubmit = async (values, { setSubmitting }) => {
    try {
      if (isEdit) {
        await updateAppointment(id, values);
        toastr.success('Appointment updated successfully');
      } else {
        await addAppointment(values);
        toastr.success('Appointment added successfully');
      }
      history.push('/appointments');
    } catch (error) {
      toastr.error('Failed to save appointment');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="appointment-form-page">
      <h2>{isEdit ? 'Edit Appointment' : 'Add Appointment'}</h2>
      <Formik
        initialValues={{
          firstName: '',
          lastName: '',
          mobileNumber: '',
          birthDate: '',
          gender: '',
          disease: '',
          history: '',
          appointmentDateTime: '',
        }}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        {({ isSubmitting }) => (
          <Form>
            <div className="form-group">
              <label htmlFor="firstName">First Name</label>
              <Field type="text" name="firstName" className="form-control" />
            </div>
            <div className="form-group">
              <label htmlFor="lastName">Last Name</label>
              <Field type="text" name="lastName" className="form-control" />
            </div>
            <div className="form-group">
              <label htmlFor="mobileNumber">Mobile Number</label>
              <Field type="text" name="mobileNumber" className="form-control" />
            </div>
            <div className="form-group">
              <label htmlFor="birthDate">Birth Date</label>
              <Field type="date" name="birthDate" className="form-control" />
            </div>
            <div className="form-group">
              <label>Gender</label>
              <div>
                <Field type="radio" name="gender" value="Male" /> Male
                <Field type="radio" name="gender" value="Female" /> Female
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="disease">Disease</label>
              <Field as="select" name="disease" className="form-control">
                <option value="">Select Disease</option>
                {diseases.map(disease => (
                  <option key={disease} value={disease}>{disease}</option>
                ))}
              </Field>
            </div>
            <div className="form-group">
              <label htmlFor="history">History</label>
              <Field as="textarea" name="history" className="form-control" />
            </div>
            <div className="form-group">
              <label htmlFor="appointmentDateTime">Appointment Date and Time</label>
              <Field type="datetime-local" name="appointmentDateTime" className="form-control" />
            </div>
            <button type="submit" className="btn btn-primary" disabled={isSubmitting}>
              Save
            </button>
            <button type="reset" className="btn btn-secondary">
              Reset
            </button>
          </Form>
        )}
      </Formik>
    </div>
  );
};

export default AppointmentForm;
