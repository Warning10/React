import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { getAppointments, deleteAppointment } from '../services/api';
import toastr from 'toastr';

const Appointments = () => {
  const [appointments, setAppointments] = useState([]);
  const history = useNavigate();

  useEffect(() => {
    const fetchAppointments = async () => {
      const data = await getAppointments();
      setAppointments(data);
    };

    fetchAppointments();
  }, []);

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this appointment?')) {
      try {
        await deleteAppointment(id);
        setAppointments(appointments.filter(appointment => appointment.id !== id));
        toastr.success('Appointment deleted successfully');
      } catch (error) {
        toastr.error('Failed to delete appointment');
      }
    }
  };

  return (
    <div className="appointments-page">
      <h2>List of Appointments</h2>
      <Link to="/appointment/new" className="btn btn-primary">Add Appointment</Link>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Mobile Number</th>
            <th>Birth Date</th>
            <th>Gender</th>
            <th>Disease</th>
            <th>Appointment Date and Time</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {appointments.map(appointment => (
            <tr key={appointment.id}>
              <td>{appointment.firstName}</td>
              <td>{appointment.lastName}</td>
              <td>{appointment.mobileNumber}</td>
              <td>{appointment.birthDate}</td>
              <td>{appointment.gender}</td>
              <td>{appointment.disease}</td>
              <td>{appointment.appointmentDateTime}</td>
              <td>
                <Link to={`/appointment/${appointment.id}/edit`} className="btn btn-link">Edit</Link>
                <button onClick={() => handleDelete(appointment.id)} className="btn btn-link">Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Appointments;
