import React from 'react';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

const Header = ({ user, onLogout }) => {
  const history = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('user');
    onLogout();
    history.push('/login');
  };

  return (
    <header className="header">
      <div className="container">
        <img src="logo.png" alt="Company Logo" className="logo" />
        <h1>Company Name</h1>
        {user && (
          <div>
            <span>Welcome {user.firstName} {user.lastName}</span>
            <button onClick={handleLogout} className="btn btn-link">Logout</button>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
