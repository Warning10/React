import axios from 'axios';

const API_URL = 'http://localhost:5000';

export const login = async (email, password) => {
  const response = await axios.get(`${API_URL}/users?email=${email}&password=${password}`);
  const users = response.data;
  if (users.length > 0) {
    return users[0];
  } else {
    throw new Error('Invalid email or password');
  }
};

export const getAppointments = async () => {
  const response = await axios.get(`${API_URL}/appointments`);
  return response.data;
};

export const getDiseases = async () => {
  const response = await axios.get(`${API_URL}/diseases`);
  return response.data;
};

export const addAppointment = async (appointment) => {
  const response = await axios.post(`${API_URL}/appointments`, appointment);
  return response.data;
};

export const updateAppointment = async (id, appointment) => {
  const response = await axios.put(`${API_URL}/appointments/${id}`, appointment);
  return response.data;
};

export const deleteAppointment = async (id) => {
  await axios.delete(`${API_URL}/appointments/${id}`);
};

export const getAppointmentById = async (id) => {
  const response = await axios.get(`${API_URL}/appointments/${id}`);
  return response.data;
};
