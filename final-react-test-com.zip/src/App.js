import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import LoginForm from './components/Login';
import AdminDashboard from './components/AdminDashboard';
import AddEditAppointment from './components/AddEditAppointment';

const App = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem('user'));
    if (storedUser) {
      setUser(storedUser);
    }
    setLoading(false);  // Set loading to false after checking local storage
  }, []);

  const handleLogin = (user) => {
    setUser(user);
    localStorage.setItem('user', JSON.stringify(user));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  if (loading) {
    return <div>Loading...</div>;  // Display loading state while checking local storage
  }

  return (
    <Router>
      <Header loggedIn={!!user} onLogout={handleLogout} />
      <div className="container mt-5">
        <Routes>
          <Route path="/login" element={<LoginForm onLogin={handleLogin} />} />
          {user && user.role === 'admin' ? (
            <>
              <Route path="/admin-dashboard" element={<AdminDashboard />} />
              <Route path="/add-appointment" element={<AddEditAppointment />} />
              <Route path="/edit-appointment/:id" element={<AddEditAppointment />} />
              <Route path="*" element={<Navigate to="/admin-dashboard" />} />
            </>
          ) : (
            <Route path="*" element={<Navigate to="/login" />} />
          )}
        </Routes>
      </div>
      <Footer />
    </Router>
  );
};

export default App;
