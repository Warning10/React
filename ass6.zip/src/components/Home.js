import React from 'react'

export const Home = () => {
  return (
    <div style={{"height": "74vh"}} className='container my-5'>
        <h2 className='text-center mb-3'> Home page</h2>
    </div>
  )
}
