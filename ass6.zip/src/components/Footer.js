import React from "react";
import "../assests/Footer.css";

// component for rendering a footer with copyright information.
const Footer = () => {
  // get current date and format it
  const currentDate = new Date();
  const formattedDate = currentDate.toLocaleDateString("en-GB");

  // render the footer component
  return (
    <footer className="main-footer">
      <div className="copyright">
        <p>
          Aress Software & Education Technologies (P) Ltd. © {formattedDate} All
          rights reserved.{" "}
        </p>
      </div>
    </footer>
  );
};

export default Footer;
