import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import axios from "axios";

const validationSchema = Yup.object().shape({
  title: Yup.string().required("Title is required"),
  body: Yup.string().required("Body is required"),
});

export const PostForm = (props) => {
  const initialValues = {
    title: props.posts.title || "",
    body: props.posts.body || "",
  };

  const handleSubmit = (values, { setSubmitting }) => {
    if (props.posts.id) {
      // Update existing post
      axios
        .patch(`http://localhost:3004/posts/${props.posts.id}`, values)
        .then((response) => {
          props.showList(); // Refresh the list after update
        })
        .catch((error) => {
          console.error("Error updating post:", error);
        })
        .finally(() => {
          setSubmitting(false);
        });
    } else {
      // Create new post
      values.createdAt = new Date().toISOString().slice(0, 10);
      axios
        .post("http://localhost:3004/posts", values)
        .then((response) => {
          props.showList(); // Refresh the list after creation
        })
        .catch((error) => {
          console.error("Error creating post:", error);
        })
        .finally(() => {
          setSubmitting(false);
        });
    }
  };

  return (
    <>
      <h2 className="text-center mb-3">
        {props.posts.id ? "Edit Post" : "Create New Post"}
      </h2>

      <div className="row">
        <div className="col-lg-6 mx-auto">
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
          >
            {({ isSubmitting }) => (
              <Form>
                <div className="mb-3">
                  <label className="col-form-label">Title</label>
                  <Field
                    type="text"
                    name="title"
                    className="form-control"
                  />
                  <ErrorMessage
                    name="title"
                    component="div"
                    className="alert alert-warning"
                  />
                </div>

                <div className="mb-3">
                  <label className="col-form-label">Body</label>
                  <Field
                    as="textarea"
                    name="body"
                    className="form-control"
                  />
                  <ErrorMessage
                    name="body"
                    component="div"
                    className="alert alert-warning"
                  />
                </div>

                <div className="row">
                  <div className="offset-sm-4 col-sm-4">
                    <button
                      className="btn btn-primary btn-sm me-3"
                      type="submit"
                      disabled={isSubmitting}
                    >
                      Save
                    </button>
                  </div>
                  <div className="col-sm-4">
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={() => props.showList()}
                      disabled={isSubmitting}
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </Form>
            )}
          </Formik>
        </div>
      </div>
    </>
  );
};

