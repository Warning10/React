import React, { useState, useEffect } from "react";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ConfirmationModal from "./ConfirmationModal";
import PostViewModal from "./PostViewModal";
import { Table, Button } from "react-bootstrap";
import "../assests/PostList.css"; // Import CSS file for PostList component

export const PostList = (props) => {
  const [posts, setPosts] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [postIdToDelete, setPostIdToDelete] = useState(null);
  const [postToView, setPostToView] = useState(null);
  const [showViewModal, setShowViewModal] = useState(false);

  useEffect(() => {
    fetchPosts();
  }, []);

  function fetchPosts() {
    axios
      .get("http://localhost:3004/posts")
      .then((response) => {
        setPosts(response.data.reverse());
      })
      .catch((error) => {
        console.error("Error fetching posts:", error);
        toast.error("Error fetching posts");
      });
  }

  function confirmDelete(id) {
    setPostIdToDelete(id);
    setShowModal(true);
  }

  function handleDelete() {
    axios
      .delete(`http://localhost:3004/posts/${postIdToDelete}`)
      .then((response) => {
        fetchPosts(); // Refresh the list after deletion
        setShowModal(false); // Close the modal after deletion
        toast.success("Post deleted successfully");
      })
      .catch((error) => {
        console.error("Error deleting post:", error);
        toast.error("Error deleting post");
      });
  }

  function cancelDelete() {
    setPostIdToDelete(null);
    setShowModal(false);
  }

  function viewPost(post) {
    setPostToView(post);
    setShowViewModal(true);
  }

  function closeViewModal() {
    setShowViewModal(false);
  }

  return (
    <>
      <ToastContainer />
      <h2 className="text-center mb-3">List of Posts</h2>
      <button
        onClick={() => props.showForm({})}
        type="button"
        className="btn btn-primary me-2"
      >
        Create
      </button>
      <button
        onClick={() => fetchPosts()}
        type="button"
        className="btn btn-outline-primary me-2"
      >
        Refresh
      </button>
      <div className="container">
        <Table striped bordered hover>
          <thead>
            <tr>
              <th className="col-1">#</th>
              <th className="col-3">Title</th>
              <th className="col-6">Body</th>
              <th className="col-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {posts.map((post, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{post.title}</td>
                <td>
                  {post.body.length >= 50
                    ? `${post.body.slice(0, 50)}...`
                    : post.body}
                </td>
                <td className="d-flex align-items-center">
                  <Button
                    variant="primary"
                    size="sm"
                    className="me-2"
                    onClick={() => props.showForm(post)}
                  >
                    Edit
                  </Button>
                  <Button
                    variant="info"
                    size="sm"
                    className="me-2"
                    onClick={() => viewPost(post)}
                  >
                    View
                  </Button>
                  <Button
                    variant="danger"
                    size="sm"
                    onClick={() => confirmDelete(post.id)}
                  >
                    Delete
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>

      {showModal && (
        <ConfirmationModal
          message="Are you sure you want to delete this post?"
          onConfirm={handleDelete}
          onCancel={cancelDelete}
        />
      )}

      {showViewModal && (
        <PostViewModal post={postToView} onClose={closeViewModal} />
      )}
    </>
  );
};

